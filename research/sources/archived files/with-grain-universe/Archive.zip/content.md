# Content

Path: Content

Contains 2 highlights

## Highlights

### - [ ] "Aquinas's contention that the truth about God that reason can discover comes mixed with many errors. Aquinas says the same thing about our knowledge of the natural law, because some propositions are evident only to the wise. That is why in matters of our knowledge of God and our knowledge of God's law, we need training from one another." 
- **Location**: Loc 303
- Varieties of Theological Work  
*Tags: [file] [highlight]*

---

### - [ ] "Most recent Christian theology and practice is not countcrcultural. Indeed, deed, it is my contention that the reason Christian convictions have lost their power for many Christians and non-Christians alike is that many Christians, and in particular most Christian theologians, have failed to challenge the cultural accommodation of the church to the world." 
- **Location**: Locations 1974-1976  
*Tags: [file] [highlight]*

---

